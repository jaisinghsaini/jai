package com.loan.service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAdjusters;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import org.springframework.stereotype.Service;

import com.loan.dto.LoanRepayment;
import com.loan.model.Loan;

@Service
public class LoanServiceImpl implements LoanService{
	
	DateTimeFormatter inputFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.ENGLISH);
	DateTimeFormatter outputFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.ENGLISH);

	@Override
	public List<LoanRepayment> generatePlan(Loan loan) {
		List<LoanRepayment> loanRepaymentList = new ArrayList<LoanRepayment>();
		LocalDateTime localDate = LocalDateTime.parse(loan.getStartDate(), inputFormatter).with(TemporalAdjusters.firstDayOfMonth());
		
		double interest = 0.0;
		double rate=loan.getNominalRate()/(12*100); 
        double time=loan.getDuration(); 
      
      // Calculating annuity(EMI)
        double annuity = (loan.getLoanAmount()*rate*Math.pow(1+rate,time))/(Math.pow(1+rate,time)-1);
		annuity = new BigDecimal(annuity).setScale(2, RoundingMode.HALF_UP).doubleValue();
		
		for(int i=1;i<=loan.getDuration();i++) {
			String formattedDate = outputFormatter.format(localDate);
			LoanRepayment loanRepayment = new LoanRepayment();
			// calculating interest
			interest = (loan.getNominalRate()/100 * 30 * loan.getLoanAmount())/360;
			interest = getDouble(interest);	
			
			double principal = getDouble(annuity - interest);
			///principal = new BigDecimal(principal).setScale(2, RoundingMode.HALF_UP).doubleValue();
			loanRepayment.setBorrowerPaymentAmount(annuity);
			loanRepayment.setDate(formattedDate);
			localDate = localDate.plusMonths(1);
			loanRepayment.setInitialOutstandingPrincipal(getDouble(loan.getLoanAmount()));
			loanRepayment.setInterest(interest);
			loanRepayment.setPrincipal(principal);
			double remainingOutstandingPrincipal = getDouble(loan.getLoanAmount() - principal);
			///new BigDecimal(loan.getLoanAmount() - principal).setScale(2, RoundingMode.HALF_UP).doubleValue();
			loanRepayment.setRemainingOutstandingPrincipal(remainingOutstandingPrincipal);
			loan.setLoanAmount(loanRepayment.getRemainingOutstandingPrincipal());
			loanRepaymentList.add(loanRepayment);
			// Last EMI adjustment
			if(i==loan.getDuration() && loanRepayment.getRemainingOutstandingPrincipal() < 1) {
				loanRepayment.setPrincipal(getDouble(principal + remainingOutstandingPrincipal));
				loanRepayment.setBorrowerPaymentAmount(annuity + remainingOutstandingPrincipal);
				loanRepayment.setRemainingOutstandingPrincipal(0);
			}
		}
		
		
		
		return loanRepaymentList;
	}
	
	private double getDouble(double initialValue) {
		return new BigDecimal(initialValue).setScale(2, RoundingMode.HALF_UP).doubleValue();
	}

}
