package com.loan.service;

import java.util.List;

import com.loan.dto.LoanRepayment;
import com.loan.model.Loan;

public interface LoanService {

	List<LoanRepayment> generatePlan(Loan loan);

}
