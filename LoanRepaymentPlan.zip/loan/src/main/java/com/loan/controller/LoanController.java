package com.loan.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.loan.dto.LoanRepayment;
import com.loan.model.Loan;
import com.loan.service.LoanService;

/**
 * @author JAISINGH
 * Nov 24, 20191:01:30 PM
 */
@ComponentScan("com.loan.service")
@RestController
public class LoanController {

	@Autowired
	LoanService _loanService;
	
	@PostMapping(path = "/generate-plan")
	public List<LoanRepayment> generatePlan(@RequestBody Loan loan) {

		return _loanService.generatePlan(loan);
	}
}
